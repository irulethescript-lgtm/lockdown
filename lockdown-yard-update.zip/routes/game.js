const express = require('express');
const { db, run, get, all, getUser, addEvent, withTransaction } = require('../middleware/db');
const { requireAuth } = require('../middleware/auth');
const { MISSIONS, ITEMS, CELL_AMENITIES, WEAPONS, ARMOR, GEAR, DRUGS, PRISONS, getTitle, levelUpCheck, JOBS } = require('../middleware/gamedata');
const { progressionAction, getDailyProgress, recordActivity, getMastery, getGymProgress, GYMS } = require('../middleware/progression');
const { COURSES, APPROACHES, STANCES, crimeQuote, recoveryGroup, simulateFight } = require('../middleware/dynamics');
const { ROUTES: TRAVEL_ROUTES, GOODS, TRAVEL_ITEMS, BAGS, wholeNumber, getTravelPage, takeInventory, addInventory, receiveCollectible } = require('../middleware/travel');
const router = express.Router();

function rnd(max) { return Math.floor(Math.random() * max); }

function statBlock(u) {
  return {
    hp: u.hp, max_hp: u.max_hp, energy: u.energy, max_energy: u.max_energy,
    nerve: u.nerve, max_nerve: u.max_nerve, xp: u.xp, xp_needed: u.xp_needed,
    cash: u.cash, bank: u.bank || 0, rep: u.rep, level: u.level,
    strength: u.strength, defense: u.defense, speed: u.speed,
    stamina: u.stamina ?? 100, heat: u.heat || 0, perks: u.perks,
    wins: u.wins, losses: u.losses, travel: u.travel,
    favors: u.favors || 0,
    job_key: u.job_key || null,
    in_hospital: u.in_hospital, hospital_until: u.hospital_until,
    in_jail: u.in_jail, jail_until: u.jail_until,
  };
}

async function saveUser(u, execute = run) {
  // Always save BASE stats (before cell augments) so bonuses don't permanently stack
  const base = (stat, key) => u[key] === undefined ? u[stat] : u[key] + u[stat] - u._effectiveStats[stat];
  const baseStrength = base('strength', '_baseStrength');
  const baseDefense = base('defense', '_baseDefense');
  const baseSpeed = base('speed', '_baseSpeed');
  const baseMaxHp = base('max_hp', '_baseMaxHp');
  const baseMaxEn = base('max_energy', '_baseMaxEnergy');
  const baseMaxNv = base('max_nerve', '_baseMaxNerve');
  const baseStamina  = u._baseStamina   !== undefined ? u._baseStamina   + (u.stamina   - (u._effectiveStamina ?? u._baseStamina)) : (u.stamina ?? 100);

  await execute(`UPDATE users SET level=?,xp=?,xp_needed=?,hp=?,max_hp=?,energy=?,max_energy=?,
    nerve=?,max_nerve=?,stamina=?,strength=?,defense=?,speed=?,cash=?,bank=?,rep=?,
    wins=?,losses=?,gang_id=?,in_hospital=?,hospital_until=?,hospital_reason=?,
    in_jail=?,jail_until=?,jail_reason=?,cell_size=?,favors=?,blurb=?,job_key=?,job_prison_id=?,last_daily_pay=? WHERE id=?`,
    [u.level,u.xp,u.xp_needed,
     u.hp, baseMaxHp, u.energy, baseMaxEn,
     u.nerve, baseMaxNv, Math.max(0,Math.min(100,baseStamina)),
     baseStrength, baseDefense, baseSpeed,
     u.cash,u.bank||0,u.rep,u.wins,u.losses,u.gang_id||null,
     u.in_hospital,u.hospital_until||0,u.hospital_reason||null,
     u.in_jail,u.jail_until||0,u.jail_reason||null,u.cell_size||'8x12',
     u.favors||0,u.blurb||'',u.job_key||null,u.job_prison_id||null,u.last_daily_pay||0,
     u.id]);
}

async function renderPage(res, view, user, extra = {}) {
  const gang = user.gang_id ? await get('SELECT * FROM gangs WHERE id=?', [user.gang_id]) : null;
  const unreadMail = (await get('SELECT COUNT(*) as c FROM mail WHERE to_id=? AND read=0', [user.id]))?.c || 0;
  const unreadEvents = (await get('SELECT COUNT(*) as c FROM events WHERE user_id=? AND read=0', [user.id]))?.c || 0;
  const title = getTitle(user.rep);
  const xpPct  = Math.floor((user.xp / user.xp_needed) * 100);
  const hpPct  = Math.floor((user.hp / user.max_hp) * 100);
  const energyPct = Math.floor((user.energy / user.max_energy) * 100);
  const nervePct  = Math.floor((user.nerve / user.max_nerve) * 100);
  res.render(view, { user, gang, title, unreadMail, unreadEvents, xpPct, hpPct, energyPct, nervePct, PRISONS, JOBS, ...extra });
}

// ── HOME ──
router.get('/', requireAuth, (req, res) => res.redirect('/prison'));

// ── PRISON ──
router.get('/prison', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const prison = PRISONS.find(p => p.id === user.prison_id) || PRISONS[0];
  const daily = await getDailyProgress(user.id);
  const masteryRows = await all('SELECT * FROM crime_mastery WHERE user_id=? ORDER BY successes DESC, crime_key LIMIT 3', [user.id]);
  const recentEvents = await all('SELECT * FROM events WHERE user_id=? ORDER BY id DESC LIMIT 5', [user.id]);
  const nextPrison = PRISONS.find(p => p.level_req > user.level);
  const activeCourse = await get('SELECT * FROM education WHERE user_id=? AND completed_at IS NULL', [user.id]);
  const crimeNames = Object.values(CRIME_ZONES).flatMap(z => z.crimes);
  const specialties = masteryRows.map(row => ({ ...getMastery(row), name: crimeNames.find(c => c.key === row.crime_key)?.name || row.crime_key }));
  await renderPage(res, 'prison', user, { prison, daily, specialties, recentEvents, nextPrison, activeCourse, COURSES });
});

// ── ACCOUNT ──
router.get('/account', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const recentAttacks = await all(`SELECT a.*,u.username as attacker_name,u2.username as defender_name
    FROM attacks a JOIN users u ON u.id=a.attacker_id JOIN users u2 ON u2.id=a.defender_id
    WHERE a.attacker_id=? OR a.defender_id=? ORDER BY a.created_at DESC LIMIT 10`, [user.id, user.id]);
  await renderPage(res, 'account', user, { recentAttacks });
});

// ── CELL ──
router.get('/cell', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  // Get placed amenities — include protected status
  const placedRows   = await all('SELECT * FROM cell_amenities WHERE user_id=? AND placed_tile IS NOT NULL', [user.id]);
  const unplacedRows = await all('SELECT * FROM cell_amenities WHERE user_id=? AND placed_tile IS NULL', [user.id]);
  // Build placed map: tile -> amenity
  const placedMap = {};
  let augments = { max_hp: 0, strength: 0, defense: 0, speed: 0, max_energy: 0, max_nerve: 0, stamina: 0 };
  placedRows.forEach(row => {
    const amenity = CELL_AMENITIES[row.item_key];
    if (amenity) {
      // Include protected flag so cell view can show the lock icon
      placedMap[row.placed_tile] = { ...amenity, key: row.item_key, db_id: row.id, protected: row.protected || 0 };
      Object.entries(amenity.effect).forEach(([stat, val]) => { if (augments[stat] !== undefined) augments[stat] += val; });
    }
  });
  // Cell grid size
  const [cols, rows_count] = (user.cell_size || '8x12').split('x').map(Number);
  const totalTiles = cols * rows_count;
  await renderPage(res, 'cell', user, { placedMap, unplacedRows, augments, totalTiles, cols, CELL_AMENITIES });
});

router.post('/cell/place', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const { db_id, tile } = req.body;
  const amenity = await get('SELECT * FROM cell_amenities WHERE id=? AND user_id=?', [db_id, user.id]);
  if (!amenity) return res.json({ error: 'Item not found.' });
  // Check tile not already occupied
  const occupied = await get('SELECT id FROM cell_amenities WHERE user_id=? AND placed_tile=?', [user.id, tile]);
  if (occupied && occupied.id !== parseInt(db_id)) return res.json({ error: 'Tile already occupied.' });
  await run('UPDATE cell_amenities SET placed_tile=? WHERE id=?', [tile, db_id]);
  res.json({ ok: true });
});

router.post('/cell/remove', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const { db_id } = req.body;
  await run('UPDATE cell_amenities SET placed_tile=NULL WHERE id=? AND user_id=?', [db_id, user.id]);
  res.json({ ok: true });
});

router.post('/cell/clear', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  await run('UPDATE cell_amenities SET placed_tile=NULL WHERE user_id=?', [user.id]);
  res.json({ ok: true });
});

router.get('/cell-raids', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  await renderPage(res, 'cell', user, {
    placedMap: {}, unplacedRows: [], augments: { max_hp:0, strength:0, defense:0, speed:0, max_energy:0, max_nerve:0, stamina:0 },
    totalTiles: 96, cols: 8, CELL_AMENITIES,
    raidsView: true
  });
});

// ── WARDEN OFFICE ──
router.get('/warden', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  await renderPage(res, 'warden_office', user);
});

// ── WARDEN STEAL WEAPON CRIME ──
router.get('/warden/steal', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  await renderPage(res, 'warden_steal', user);
});

router.post('/warden/steal', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  if (user.nerve < 20) return res.json({ error: 'Need 20 nerve to attempt this.' });
  if (user.in_jail || user.in_hospital) return res.json({ error: 'Can\'t steal while jailed/hospitalized.' });
  user.nerve -= 20;
  const catchChance = Math.max(10, 55 - Math.floor(user.speed / 50) * 5);
  if (Math.random() * 100 < catchChance) {
    // Caught
    user.in_jail = 1;
    user.jail_until = Math.floor(Date.now()/1000) + 180;
    user.jail_reason = 'Caught stealing from the Warden\'s gun case!';
    await saveUser(user);
    return res.json({ caught: true, msg: 'Busted! The guard tackled you. 3 minutes in isolation.' });
  }
  // Success - add a weapon to inventory
  const loot = ['shiv','blade','gun','sock_rock','knuckle_wraps'][Math.floor(Math.random()*5)];
  const cash = 500 + Math.floor(Math.random() * 1500);
  user.cash += cash;
  user.xp += 25;
  user.rep += 2;
  const existing = await get("SELECT id,quantity FROM inventory WHERE user_id=? AND item_key=? AND item_type='weapon'", [user.id, loot]);
  if (existing) await run("UPDATE inventory SET quantity=quantity+1 WHERE id=?", [existing.id]);
  else await run("INSERT INTO inventory (user_id,item_key,item_type,quantity) VALUES (?,?,'weapon',1)", [user.id, loot]);
  const lvlUp = await levelUpCheck(user, run);
  await saveUser(user);
  res.json({ success: true, msg: `Got away clean! Swiped a ${loot.replace(/_/g,' ')} + $${cash.toLocaleString()}.`, loot, levelUp: lvlUp });
});

// ── WARDEN AMENITIES SHOP (per-prison, costs REP, comes protected) ──
router.get('/warden-amenities', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const prison = PRISONS.find(p => p.id === user.prison_id) || PRISONS[0];
  const ownedRows = await all('SELECT item_key, COUNT(*) as qty FROM cell_amenities WHERE user_id=? GROUP BY item_key', [user.id]);
  const ownedMap = {};
  ownedRows.forEach(o => ownedMap[o.item_key] = o.qty);
  // Build list of amenities available in this prison's warden shop
  const shopItems = (prison.warden_amenities || []).map(key => {
    const a = CELL_AMENITIES[key];
    if (!a) return null;
    // Add rep_cost if not set (default based on price tier)
    const rep = a.rep_cost || Math.ceil((a.price || 500) / 50);
    return { key, ...a, rep_cost: rep };
  }).filter(Boolean);
  await renderPage(res, 'warden_amenities', user, { shopItems, ownedMap, prison });
});

router.post('/warden-amenities/buy', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const { item_key } = req.body;
  const prison = PRISONS.find(p => p.id === user.prison_id) || PRISONS[0];
  if (!(prison.warden_amenities || []).includes(item_key)) return res.json({ error: 'Not available in your prison.' });
  const amenity = CELL_AMENITIES[item_key];
  if (!amenity) return res.json({ error: 'Item not found.' });
  const repCost = amenity.rep_cost || Math.ceil((amenity.price || 500) / 50);
  if (user.rep < repCost) return res.json({ error: `Need ${repCost} Rep. You have ${user.rep}.` });
  user.rep -= repCost;
  // Insert as PROTECTED=1 — cannot be raided
  await run('INSERT INTO cell_amenities (user_id, item_key, quantity, protected) VALUES (?,?,1,1)', [user.id, item_key]);
  await saveUser(user);
  // Transaction log
  await run(`INSERT INTO transaction_logs (type,to_id,to_name,item_key,item_type,quantity,cash_amount,note) VALUES (?,?,?,?,?,1,0,?)`,
    ['warden_buy', user.id, user.username, item_key, 'amenity', `Warden purchase: ${amenity.name} for ${repCost} Rep`]).catch(()=>{});
  res.json({ msg: `Purchased ${amenity.name}! It's protected (🔒) — cannot be raided. Go to My Cell to place it.`, user: statBlock(user) });
});

// ── WARDEN REP PURCHASE ──
router.post('/warden/buy-rep', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const { amount } = req.body;
  const qty = Math.min(parseInt(amount) || 1, 100);
  const cost = qty * 1000; // $1000 per rep point
  if (user.cash < cost) return res.json({ error: `Need $${cost.toLocaleString()}.` });
  user.cash -= cost;
  user.rep += qty;
  await saveUser(user);
  res.json({ msg: `Bought ${qty} Rep for $${cost.toLocaleString()}.`, user: statBlock(user) });
});



// ── GYM ──
router.get('/gym', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  // Get last 15 training history entries
  const history = await all(`SELECT * FROM (SELECT * FROM training_history WHERE user_id=? ORDER BY id DESC LIMIT 20) ORDER BY id ASC`, [user.id]);
  const progress = await get('SELECT energy_spent FROM gym_progress WHERE user_id=?', [user.id]);
  await renderPage(res, 'gym', user, { history, gym: getGymProgress(progress?.energy_spent), GYMS });
});

router.post('/gym/train', requireAuth, progressionAction(async (req, tx) => {
  const user = await getUser(req.session.userId, tx);
  const { stat, energy_amount } = req.body;
  if (user.in_jail || user.in_hospital) return { error: 'You cannot train while in isolation or the infirmary.' };
  const amount = typeof energy_amount === 'number' || typeof energy_amount === 'string' ? Number(energy_amount) : NaN;
  if (!Number.isSafeInteger(amount) || amount < 1) return { error: 'Enter a whole number of energy points greater than zero.' };
  if (amount > user.energy) return { error: 'Not enough energy.' };
  if (!['strength','defense','speed'].includes(stat)) return ({ error: 'Invalid stat.' });
  const currentStamina = user.stamina ?? 100;
  const staminaDrain = amount * 2;
  if (currentStamina < staminaDrain) return { error: `Need ${staminaDrain}% stamina for this session. Use less energy or wait to recover.` };
  const progress = await tx.get('SELECT energy_spent FROM gym_progress WHERE user_id=?', [user.id]);
  const gym = getGymProgress(progress?.energy_spent);
  const gain = Math.floor(amount * 2 * gym.multiplier * (1 + user.perks.training / 100));
  user.energy -= amount;
  user.stamina -= staminaDrain;
  user[stat] += gain;
  user.xp += amount * 15;
  const lvlUp = await levelUpCheck(user, async () => {});
  await saveUser(user, tx.run);
  const historyEntry = Object.fromEntries(['strength', 'defense', 'speed'].map(key => [key, user[{ strength:'_baseStrength', defense:'_baseDefense', speed:'_baseSpeed' }[key]] + user[key] - user._effectiveStats[key]]));
  await tx.run(`INSERT INTO training_history (user_id, strength, defense, speed) VALUES (?,?,?,?)`,
    [user.id, historyEntry.strength, historyEntry.defense, historyEntry.speed]);
  await tx.run(`DELETE FROM training_history WHERE user_id=? AND id NOT IN (SELECT id FROM training_history WHERE user_id=? ORDER BY trained_at DESC LIMIT 20)`,
    [user.id, user.id]);
  await tx.run(`INSERT INTO gym_progress (user_id,energy_spent) VALUES (?,?) ON CONFLICT(user_id) DO UPDATE SET energy_spent=energy_spent+excluded.energy_spent`, [user.id, amount]);
  await recordActivity(user.id, 'training', tx);
  const updatedGym = getGymProgress((progress?.energy_spent || 0) + amount);
  return ({ msg: `Trained ${stat}! +${gain} ${stat.toUpperCase()} (used ${amount} energy, -${staminaDrain}% stamina)`, user: statBlock(user), levelUp: lvlUp, gain, stat, historyEntry, gym: updatedGym, unlockedGym: updatedGym.name !== gym.name ? updatedGym.name : null });
}));

// ── YARD / PRISON VISITS ──
router.get(['/prison/yard','/yard','/travel'], requireAuth, async (req,res,next) => {
  try {
    const data=await withTransaction(async tx=>{
      const travel=await getTravelPage(req.session.userId,tx);
      const user=await getUser(req.session.userId,tx);
      return {user,travel};
    });
    await renderPage(res,'yard',data.user,{travel:data.travel,TRAVEL_ROUTES,GOODS});
  } catch(err) {next(err);}
});
router.get('/yard/state',requireAuth,async (req,res,next)=>{
  try {
    const data=await withTransaction(async tx=>{
      const travel=await getTravelPage(req.session.userId,tx);
      return {travel,user:statBlock(await getUser(req.session.userId,tx))};
    });
    res.json(data);
  } catch(err) {next(err);}
});
router.post('/yard/depart',requireAuth,progressionAction(async(req,tx)=>{
  const user=await getUser(req.session.userId,tx);
  const travel=await getTravelPage(user.id,tx);
  if(travel.phase!=='home') return {error:'Finish your current trip first.'};
  if(user.in_hospital || user.in_jail) return {error:'You cannot travel from isolation or the infirmary.'};
  const destination=TRAVEL_ROUTES.find(r=>r.id===wholeNumber(req.body.destination_id));
  if(!destination || destination.id===user.prison_id) return {error:'Choose a prison other than your home prison.'};
  if(user.cash<destination.fare) return {error:`Need $${destination.fare} for the round-trip fare.`};
  const now=Math.floor(Date.now()/1000);
  await tx.run('UPDATE users SET cash=cash-? WHERE id=?',[destination.fare,user.id]);
  await tx.run(`INSERT INTO travel_trips (user_id,origin_id,destination_id,departed_at,arrives_at,fare,capacity) VALUES (?,?,?,?,?,?,?)`,
    [user.id,user.prison_id,destination.id,now,now+destination.minutes*60,destination.fare,travel.bag.capacity]);
  const msg=`Departed for ${destination.name}. Arrival in ${destination.minutes} minutes; return fare included.`;
  await tx.run("INSERT INTO events (user_id,type,message) VALUES (?,'travel',?)",[user.id,msg]);
  return {msg,travel:await getTravelPage(user.id,tx),user:statBlock(await getUser(user.id,tx))};
}));
router.post('/yard/buy',requireAuth,progressionAction(async(req,tx)=>{
  const user=await getUser(req.session.userId,tx);
  const travel=await getTravelPage(user.id,tx);
  if(!['home','visiting'].includes(travel.phase)) return {error:'Arrive at your destination before buying cargo.'};
  const local=travel.phase==='home';
  const good=GOODS.find(g=>g.key===req.body.item_key && g.prison===(local?user.prison_id:travel.trip.destination_id));
  const quantity=wholeNumber(req.body.quantity);
  if(!good || !Number.isSafeInteger(quantity) || quantity<1) return {error:'Choose a local item and a positive whole quantity.'};
  const used=travel.cargo.reduce((sum,row)=>sum+row.quantity,0);
  if(local && quantity>50) return {error:'Buy at most 50 local souvenirs at a time.'};
  if(!local && quantity>travel.trip.capacity-used) return {error:'Not enough cargo space. Each item uses one slot.'};
  const stock=travel.stock.find(s=>s.item_key===good.key);
  if(stock.quantity<quantity) return {error:'Not enough local stock. Wait for the next restock.'};
  const cost=(local?good.sell:good.buy)*quantity;
  if(user.cash<cost) return {error:`Need $${cost} for this cargo. Your return trip is already paid.`};
  await tx.run('UPDATE users SET cash=cash-? WHERE id=?',[cost,user.id]);
  await tx.run('UPDATE travel_stock SET quantity=quantity-? WHERE item_key=?',[quantity,good.key]);
  if(local) await receiveCollectible(tx,user.id,good.key,quantity);
  else await tx.run(`INSERT INTO travel_cargo (trip_id,item_key,quantity) VALUES (?,?,?) ON CONFLICT(trip_id,item_key) DO UPDATE SET quantity=quantity+excluded.quantity`,[travel.trip.id,good.key,quantity]);
  return {msg:local ? `Collected ${quantity} × ${good.name} for $${cost} at the home exchange.` : `Packed ${quantity} × ${good.name} for $${cost}. Cargo will enter your inventory when you get home.`,travel:await getTravelPage(user.id,tx),user:statBlock(await getUser(user.id,tx))};
}));
router.post('/yard/return',requireAuth,progressionAction(async(req,tx)=>{
  const travel=await getTravelPage(req.session.userId,tx);
  if(travel.phase!=='visiting') return {error:'You can start the return trip after arriving.'};
  const destination=TRAVEL_ROUTES.find(r=>r.id===travel.trip.destination_id);
  const now=Math.floor(Date.now()/1000);
  await tx.run("UPDATE travel_trips SET status='returning',return_departed_at=?,return_arrives_at=? WHERE id=?",[now,now+destination.minutes*60,travel.trip.id]);
  return {msg:`Heading home. Your ${destination.minutes}-minute return trip is already paid.`,travel:await getTravelPage(req.session.userId,tx),user:statBlock(await getUser(req.session.userId,tx))};
}));
router.post('/yard/sell',requireAuth,progressionAction(async(req,tx)=>{
  const travel=await getTravelPage(req.session.userId,tx);
  if(travel.phase!=='home') return {error:'Bring your cargo home before selling.'};
  const good=GOODS.find(g=>g.key===req.body.item_key);
  const quantity=wholeNumber(req.body.quantity);
  if(!good || !Number.isSafeInteger(quantity) || quantity<1 || quantity>1000000) return {error:'Choose a collectible and a positive whole quantity.'};
  if(!await takeInventory(tx,req.session.userId,good.key,quantity)) return {error:'You do not own enough of that collectible.'};
  const total=quantity*good.sell;
  await tx.run('UPDATE users SET cash=cash+? WHERE id=?',[total,req.session.userId]);
  await tx.run('INSERT INTO travel_progress (user_id,sales_cash) VALUES (?,?) ON CONFLICT(user_id) DO UPDATE SET sales_cash=sales_cash+excluded.sales_cash',[req.session.userId,total]);
  await tx.run("INSERT INTO transaction_logs (type,from_id,item_key,item_type,quantity,cash_amount,note) VALUES ('collector_sale',?,?,'collectible',?,?,?)",[req.session.userId,good.key,quantity,total,`Travel collector: ${good.name}`]);
  return {msg:`Sold ${quantity} × ${good.name} for $${total}. Your discovery stays in the collection book.`,travel:await getTravelPage(req.session.userId,tx),user:statBlock(await getUser(req.session.userId,tx))};
}));
router.post('/yard/upgrade',requireAuth,progressionAction(async(req,tx)=>{
  const user=await getUser(req.session.userId,tx),travel=await getTravelPage(user.id,tx);
  if(travel.phase!=='home') return {error:'Upgrade your bag at home.'};
  const bag=travel.nextBag;
  if(!bag) return {error:'You already have the largest cargo bag.'};
  if(travel.progress.trips_completed<bag.trips) return {error:`Complete ${bag.trips} round trips to unlock this bag.`};
  if(user.cash<bag.cost) return {error:`Need $${bag.cost} for the bag upgrade.`};
  await tx.run('UPDATE users SET cash=cash-? WHERE id=?',[bag.cost,user.id]);
  await tx.run('INSERT INTO travel_progress (user_id,bag_level) VALUES (?,?) ON CONFLICT(user_id) DO UPDATE SET bag_level=excluded.bag_level',[user.id,bag.level]);
  return {msg:`Upgraded to ${bag.name}: ${bag.capacity} cargo slots.`,travel:await getTravelPage(user.id,tx),user:statBlock(await getUser(user.id,tx))};
}));
router.post('/yard/collection',requireAuth,progressionAction(async(req,tx)=>{
  const travel=await getTravelPage(req.session.userId,tx);
  if(travel.phase!=='home') return {error:'Return home to collect this reward.'};
  if(travel.progress.collection_claimed) return {error:'You have already collected this reward.'};
  if(!GOODS.every(g=>travel.discoveries.some(d=>d.item_key===g.key))) return {error:'Discover all 10 unique collectibles first.'};
  await tx.run('INSERT INTO travel_progress (user_id,collection_claimed) VALUES (?,1) ON CONFLICT(user_id) DO UPDATE SET collection_claimed=1',[req.session.userId]);
  await tx.run('UPDATE users SET cash=cash+1500,rep=rep+5 WHERE id=?',[req.session.userId]);
  await tx.run("INSERT INTO events (user_id,type,message) VALUES (?,'travel','Collection complete! Earned $1,500 and 5 reputation.')",[req.session.userId]);
  return {msg:'Collection complete! +$1,500 and +5 reputation. You keep your items.',travel:await getTravelPage(req.session.userId,tx),user:statBlock(await getUser(req.session.userId,tx))};
}));
// Retired movement endpoints cannot award old yard loot alongside the new travel loop.
router.post(['/yard/action','/yard/move','/yard/pickup','/yard/drop'],requireAuth,(req,res)=>res.json({error:'The yard is now the Travel Yard. Open /prison/yard to plan a visit.'}));

// ── CRIMES ──
const CRIME_ZONES = {
  south_dakota: {
    label: 'Ohio State Crimes',
    prison_ids: [1],
    crimes: [
      { key:'pickpocket',    name:'Pickpocket',       desc:'Lift wallets from distracted guards.',          nerve:2,  stamina:3,  cash:[80,200],   catch_chance:20, xp:5,  rep:1 },
      { key:'steal_food',    name:'Steal Food',       desc:'Swipe extra rations from the kitchen.',         nerve:3,  stamina:4,  cash:[100,300],  catch_chance:25, xp:8,  rep:1 },
      { key:'run_errands',   name:'Run Errands',      desc:'Deliver contraband between blocks.',            nerve:4,  stamina:5,  cash:[150,400],  catch_chance:30, xp:10, rep:2 },
      { key:'intimidation',  name:'Intimidation',     desc:'Shake down a weaker inmate for cash.',          nerve:6,  stamina:6,  cash:[200,500],  catch_chance:35, xp:15, rep:3 },
    ]
  },
  rikers: {
    label: 'Alcatraz Island Crimes',
    prison_ids: [2],
    crimes: [
      { key:'card_shark',    name:'Card Shark',       desc:'Hustle inmates at the card table.',             nerve:3,  stamina:4,  cash:[150,400],  catch_chance:22, xp:10, rep:2 },
      { key:'smuggle_phone', name:'Smuggle Phone',    desc:'Sneak in a contraband cell phone.',             nerve:5,  stamina:5,  cash:[250,550],  catch_chance:28, xp:15, rep:3 },
      { key:'bribery',       name:'Bribery',          desc:'Pay off a guard for special privileges.',       nerve:7,  stamina:6,  cash:[300,600],  catch_chance:32, xp:20, rep:4 },
      { key:'gang_tax',      name:'Collect Gang Tax', desc:'Demand tribute from unaffiliated inmates.',     nerve:8,  stamina:7,  cash:[400,700],  catch_chance:38, xp:25, rep:5 },
    ]
  },
  san_quentin: {
    label: "Devil’s Island Crimes",
    prison_ids: [3],
    crimes: [
      { key:'forge_docs',    name:'Forge Documents',  desc:'Fake work release papers for profit.',          nerve:5,  stamina:5,  cash:[300,600],  catch_chance:25, xp:20, rep:4 },
      { key:'drug_trade',    name:'Drug Trade',       desc:'Move product through the yard.',                nerve:8,  stamina:7,  cash:[500,900],  catch_chance:35, xp:30, rep:6 },
      { key:'extortion',     name:'Extortion',        desc:'Run a protection racket on new inmates.',       nerve:10, stamina:8,  cash:[600,1000], catch_chance:40, xp:35, rep:7 },
      { key:'heist_kitchen', name:'Kitchen Heist',    desc:'Rob the commissary supply room blind.',         nerve:12, stamina:9,  cash:[700,1200], catch_chance:45, xp:40, rep:8 },
    ]
  },
  alcatraz: {
    label: 'San Francisco Crimes',
    prison_ids: [4],
    crimes: [
      { key:'contraband_ring', name:'Contraband Ring', desc:'Manage a full contraband supply chain.',       nerve:8,  stamina:8,  cash:[600,1200], catch_chance:28, xp:40, rep:8  },
      { key:'guard_bribe2',    name:'Guard Network',   desc:'Bribe multiple guards for a safe corridor.',   nerve:12, stamina:9,  cash:[800,1400], catch_chance:35, xp:50, rep:10 },
      { key:'bank_intel',      name:'Bank Intel',      desc:'Sell financial intel to outside contacts.',    nerve:14, stamina:10, cash:[1000,1600],catch_chance:40, xp:55, rep:12 },
      { key:'murder_contract', name:'Contract Hit',    desc:'Accept a hit contract from a crime boss.',     nerve:18, stamina:12, cash:[1200,1800],catch_chance:48, xp:65, rep:15 },
    ]
  },
  the_vault: {
    label: 'Pelican Bay Crimes',
    prison_ids: [5],
    crimes: [
      { key:'crypto_fraud',  name:'Crypto Fraud',     desc:'Run crypto scams from a smuggled laptop.',     nerve:10, stamina:10, cash:[800,1500], catch_chance:25, xp:60, rep:12 },
      { key:'arms_deal',     name:'Arms Deal',        desc:'Broker a weapons deal between gangs.',         nerve:14, stamina:11, cash:[1200,1800], catch_chance:32, xp:70, rep:15 },
      { key:'prison_riot',   name:'Incite Riot',      desc:'Orchestrate chaos to rob the infirmary.',      nerve:18, stamina:13, cash:[1500,2000], catch_chance:42, xp:80, rep:18 },
      { key:'warden_heist',  name:'Warden\'s Safe',   desc:'Crack the warden\'s personal safe.',           nerve:22, stamina:15, cash:[1600,2200], catch_chance:50, xp:100,rep:25 },
    ]
  }
};

router.get('/crimes', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const zone = Object.values(CRIME_ZONES).find(z => z.prison_ids.includes(user.prison_id || 1)) || CRIME_ZONES.south_dakota;
  const rows = await all('SELECT * FROM crime_mastery WHERE user_id=?', [user.id]);
  const mastery = Object.fromEntries(zone.crimes.map(crime => [crime.key, getMastery(rows.find(r => r.crime_key === crime.key), crime, user.speed)]));
  await renderPage(res, 'crimes', user, { zone, CRIME_ZONES, mastery, APPROACHES });
});

router.post('/crimes/commit', requireAuth, progressionAction(async (req, tx) => {
  const user = await getUser(req.session.userId, tx);
  const zone = Object.values(CRIME_ZONES).find(z => z.prison_ids.includes(user.prison_id || 1));
  const crime = zone?.crimes.find(c => c.key === req.body.crime_key);
  if (!crime) return { error: 'This crime is not available in your prison.' };
  if (user.in_jail) return { error: 'You are in isolation! Serve your time or bribe out.' };
  if (user.in_hospital) return { error: "You're in the infirmary!" };
  if (user.nerve < crime.nerve) return { error: `Need ${crime.nerve} nerve to attempt this. You have ${user.nerve}.` };
  if ((user.stamina ?? 100) < crime.stamina) return { error: `Need ${crime.stamina}% stamina. You have ${user.stamina ?? 100}%.` };

  const row = await tx.get('SELECT * FROM crime_mastery WHERE user_id=? AND crime_key=?', [user.id, crime.key]);
  const approach = APPROACHES.find(a => a.key === (req.body.approach ?? 'balanced'));
  if (!approach) return { error: 'Choose a valid crime approach.' };
  const skill = getMastery(row, crime, user.speed);
  const quote = crimeQuote(crime, skill, user, approach);
  const caught = Math.random() * 100 < quote.risk;
  user.nerve -= crime.nerve;
  user.stamina = Math.max(0, (user.stamina ?? 100) - crime.stamina);
  let cashGain = 0;
  let msg;
  let jailSeconds = 0;
  if (caught) {
    jailSeconds = 60 + crime.nerve * 30;
    user.in_jail = 1;
    user.jail_until = Math.floor(Date.now() / 1000) + jailSeconds;
    user.jail_reason = `Caught committing: ${crime.name}`;
    msg = `Busted! ${crime.name} landed you in isolation for ${Math.ceil(jailSeconds / 60)} minutes.`;
  } else {
    const baseCash = Math.floor(Math.random() * (crime.cash[1] - crime.cash[0] + 1)) + crime.cash[0];
    cashGain = Math.floor(baseCash * quote.multiplier);
    user.cash += cashGain;
    user.rep += crime.rep;
    user.xp += crime.xp;
    msg = `Success! ${crime.name} earned you $${cashGain.toLocaleString()}, ${crime.xp} XP and ${crime.rep} reputation.`;
  }
  user.heat = Math.min(100, user.heat + approach.heat + (caught ? 10 : 0));
  await tx.run(`INSERT INTO player_dynamics (user_id,heat,heat_updated) VALUES (?,?,?)
    ON CONFLICT(user_id) DO UPDATE SET heat=excluded.heat,heat_updated=excluded.heat_updated`, [user.id, user.heat, Math.floor(Date.now() / 1000)]);
  msg += ` ${approach.name} approach · Heat ${user.heat}/100.`;
  // Mutate the player once, stripping passive bonuses through saveUser.
  const levelUp = await levelUpCheck(user, async () => {});
  await saveUser(user, tx.run);
  await tx.run(`INSERT INTO crime_mastery (user_id, crime_key, attempts, successes) VALUES (?,?,1,?)
    ON CONFLICT(user_id, crime_key) DO UPDATE SET attempts=attempts+1, successes=successes+excluded.successes`, [user.id, crime.key, caught ? 0 : 1]);
  await recordActivity(user.id, 'crimes', tx);
  await tx.run("INSERT INTO events (user_id,type,message) VALUES (?,'crime',?)", [user.id, msg]);
  const mastery = getMastery({ attempts: (row?.attempts || 0) + 1, successes: (row?.successes || 0) + (caught ? 0 : 1) }, crime, user.speed);
  return { caught, msg, cashGain, jailSeconds, mastery, risk: quote.risk, user: statBlock(user), levelUp };
}));

router.post('/daily/claim', requireAuth, progressionAction(async (req, tx) => {
  const daily = await getDailyProgress(req.session.userId, tx);
  if (daily.claimed) return { error: 'You already claimed today’s reward.' };
  if (!daily.complete) return { error: 'Complete both daily objectives first.' };
  await tx.run('UPDATE daily_progress SET claimed=1 WHERE user_id=? AND day=?', [req.session.userId, daily.day]);
  await tx.run('UPDATE users SET cash=cash+500, rep=rep+3 WHERE id=?', [req.session.userId]);
  const msg = 'Daily objectives complete! You received $500 and 3 reputation.';
  await tx.run("INSERT INTO events (user_id,type,message) VALUES (?,'daily',?)", [req.session.userId, msg]);
  return { msg, user: statBlock(await getUser(req.session.userId, tx)) };
}));

// ── EDUCATION ──
router.get('/education', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const courses = await all('SELECT * FROM education WHERE user_id=?', [user.id]);
  await renderPage(res, 'education', user, { COURSES, courses, now: Math.floor(Date.now() / 1000) });
});
router.post('/education/start', requireAuth, progressionAction(async (req, tx) => {
  const user = await getUser(req.session.userId, tx);
  const course = COURSES.find(c => c.key === req.body.course_key);
  if (!course) return { error: 'Unknown course.' };
  if (user.in_jail || user.in_hospital) return { error: 'You cannot enroll while in isolation or the infirmary.' };
  const courses = await tx.all('SELECT * FROM education WHERE user_id=?', [user.id]);
  if (courses.some(c => c.course_key === course.key)) return { error: 'You have already enrolled in this course.' };
  if (courses.some(c => c.completed_at === null)) return { error: 'Finish your current course first.' };
  if (course.requires && !courses.some(c => c.course_key === course.requires && c.completed_at !== null)) return { error: 'Complete the prerequisite course first.' };
  if (user.cash < course.cost) return { error: `Need $${course.cost.toLocaleString()} to enroll.` };
  const now = Math.floor(Date.now() / 1000);
  await tx.run('UPDATE users SET cash=cash-? WHERE id=?', [course.cost, user.id]);
  await tx.run('INSERT INTO education (user_id,course_key,started_at,finishes_at) VALUES (?,?,?,?)', [user.id, course.key, now, now + course.duration]);
  const msg = `Enrolled in ${course.name}. Study continues while you are offline.`;
  await tx.run("INSERT INTO events (user_id,type,message) VALUES (?,'education',?)", [user.id, msg]);
  return { msg, user: statBlock(await getUser(user.id, tx)) };
}));
router.post('/education/complete', requireAuth, progressionAction(async (req, tx) => {
  const course = COURSES.find(c => c.key === req.body.course_key);
  if (!course) return { error: 'Unknown course.' };
  const row = await tx.get('SELECT * FROM education WHERE user_id=? AND course_key=?', [req.session.userId, course.key]);
  if (!row || row.completed_at !== null) return { error: 'No unfinished course to complete.' };
  const now = Math.floor(Date.now() / 1000);
  if (row.finishes_at > now) return { error: 'Your course is still in progress.' };
  await tx.run('UPDATE education SET completed_at=? WHERE user_id=? AND course_key=?', [now, req.session.userId, course.key]);
  const msg = `${course.name} complete! ${course.desc}`;
  await tx.run("INSERT INTO events (user_id,type,message) VALUES (?,'education',?)", [req.session.userId, msg]);
  return { msg, user: statBlock(await getUser(req.session.userId, tx)) };
}));

// ── MISSIONS (kept for legacy, redirects to crimes) ──
router.get('/missions', requireAuth, async (req, res) => {
  res.redirect('/crimes');
});


// ── BATTLES ──
router.get('/battles', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const now = Math.floor(Date.now()/1000);
  const targets = await all(
    `SELECT id,username,level,hp,max_hp,strength,defense,speed,rep,gang_id,last_active,in_hospital,in_jail,hospital_until,jail_until
     FROM users WHERE id!=? AND prison_id=? ORDER BY last_active DESC LIMIT 40`,
    [user.id, user.prison_id]
  );
  const history = await all(
    `SELECT a.*,u.username as opp_name FROM attacks a
     JOIN users u ON u.id=CASE WHEN a.attacker_id=? THEN a.defender_id ELSE a.attacker_id END
     WHERE a.attacker_id=? OR a.defender_id=? ORDER BY a.created_at DESC LIMIT 15`,
    [user.id, user.id, user.id]
  );
  // Load per-target cooldowns so view can show "wait X min"
  const cds = await all('SELECT defender_id, last_attack FROM attack_cooldowns WHERE attacker_id=?', [user.id]).catch(()=>[]);
  const cdMap = {};
  cds.forEach(c => { cdMap[c.defender_id] = c.last_attack; });
  await renderPage(res, 'battles', user, { targets, history, now, cdMap, STANCES });
});

router.post(['/battles/attack', '/mug'], requireAuth, progressionAction(async (req, tx) => {
  const attacker = await getUser(req.session.userId, tx);
  const tid = typeof req.body.target_id === 'number' || typeof req.body.target_id === 'string' ? Number(req.body.target_id) : NaN;
  const ending = req.path === '/mug' ? 'mug' : (req.body.ending ?? 'mug');
  const stance = req.body.stance ?? 'balanced';
  if (!Number.isSafeInteger(tid) || tid <= 0 || tid === attacker.id) return { error: 'Invalid target.' };
  if (!['mug', 'leave', 'hospitalize'].includes(ending) || !Object.hasOwn(STANCES, stance)) return { error: 'Choose a valid stance and victory outcome.' };
  if (attacker.energy < 5) return { error: 'Need 5 energy to fight.' };
  if ((attacker.stamina ?? 100) < 10) return { error: 'Need at least 10% stamina to fight.' };
  if (attacker.in_hospital || attacker.in_jail) return { error: "You can't fight from here." };
  const now = Math.floor(Date.now() / 1000);
  const cd = await tx.get('SELECT last_attack FROM attack_cooldowns WHERE attacker_id=? AND defender_id=?', [attacker.id, tid]);
  if (cd && now - cd.last_attack < 600) return { error: `Wait ${Math.ceil((600 - (now - cd.last_attack)) / 60)} more minutes before attacking this person again.` };
  const defender = await getUser(tid, tx);
  if (!defender) return { error: 'Invalid target.' };
  if (defender.travel.phase !== 'home') return { error: 'Target is away on a prison visit.' };
  if (defender.in_hospital || defender.in_jail) return { error: 'Target is recovering in the infirmary or isolation.' };
  if (defender.prison_id !== attacker.prison_id) return { error: 'Target is in a different prison.' };
  attacker.energy -= 5;
  await tx.run('INSERT OR REPLACE INTO attack_cooldowns (attacker_id,defender_id,last_attack) VALUES (?,?,?)', [attacker.id, tid, now]);
  const fight = simulateFight(attacker, defender, stance);
  attacker.stamina = Math.max(0, attacker.stamina - 10);
  defender.stamina = Math.max(0, defender.stamina - 5);
  attacker.hp = Math.max(1, fight.aHp);
  defender.hp = Math.max(1, fight.dHp);
  let cashStolen = 0, repGained = 0, xpGain = 0;
  const hospitalize = (loser, seconds, reason) => {
    loser.in_hospital = 1;
    loser.hospital_until = now + seconds;
    loser.hospital_reason = reason;
    loser.hp = Math.max(1, Math.floor(loser.max_hp * 0.2));
  };
  let msg;
  if (fight.result === 'win') {
    attacker.wins++; defender.losses++;
    const baseXp = Math.max(15, 20 + defender.level * 5 + (defender.level - attacker.level) * 10);
    xpGain = Math.floor(baseXp * (ending === 'leave' ? 1.5 : ending === 'mug' ? 0.6 : 1));
    repGained = ending === 'leave' ? 3 + Math.floor(defender.level / 3) : ending === 'hospitalize' ? 2 : 1;
    if (ending === 'mug') {
      cashStolen = Math.max(0, Math.floor(defender.cash * 0.08));
      defender.cash -= cashStolen; attacker.cash += cashStolen;
    }
    attacker.rep += repGained; attacker.xp += xpGain;
    const seconds = ending === 'hospitalize' ? 600 : ending === 'mug' ? 90 : 60;
    hospitalize(defender, seconds, `Defeated by ${attacker.username} (${ending})`);
    msg = `Victory! ${ending === 'mug' ? `Mugged $${cashStolen.toLocaleString()}.` : ending === 'leave' ? 'Left your opponent for extra experience.' : 'Opponent hospitalized for 10 minutes.'} +${xpGain} XP, +${repGained} reputation.`;
  } else if (fight.result === 'loss') {
    attacker.losses++; defender.wins++;
    hospitalize(attacker, 180, `Lost a fight against ${defender.username}`);
    msg = 'Defeat. You are in the infirmary for 3 minutes.';
  } else {
    msg = 'Stalemate after 20 rounds. Both keep their remaining HP; no cash or victory rewards change hands.';
  }
  fight.log.push(msg);
  const levelUp = await levelUpCheck(attacker, async () => {});
  await saveUser(attacker, tx.run);
  await saveUser(defender, tx.run);
  await tx.run(`INSERT INTO attacks (attacker_id,defender_id,attacker_won,damage_dealt,damage_taken,cash_stolen,rep_gained,log,result,ending,stance) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [attacker.id, tid, fight.result === 'win' ? 1 : 0, fight.damageDealt, fight.damageTaken, cashStolen, repGained, fight.log.join('\n'), fight.result, ending, stance]);
  await tx.run("INSERT INTO events (user_id,type,message) VALUES (?,'attacked',?)", [defender.id, `${attacker.username} attacked you: ${fight.result === 'draw' ? 'stalemate' : fight.result === 'win' ? `you lost (${ending}), $${cashStolen} taken` : 'you defended successfully'}.`]);
  await tx.run("INSERT INTO events (user_id,type,message) VALUES (?,'battle',?)", [attacker.id, msg]);
  return { result: fight.result, won: fight.result === 'win', success: fight.result === 'win', ending, stance, log: fight.log, cashStolen, repGained, xpGain, user: statBlock(attacker), levelUp, msg };
}));

// ── INFIRMARY ──
router.get('/prison/infirmary', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const now = Math.floor(Date.now() / 1000);
  // Get all players currently in hospital
  const icuList = await all(`SELECT id,username,level,in_hospital,hospital_until,hospital_reason,gang_id FROM users WHERE in_hospital=1 ORDER BY hospital_until ASC`);
  const hospitalUntil = user.hospital_until || 0;
  const timeLeft = Math.max(0, hospitalUntil - now);
  // Bribe cost = $500 base + $100 per minute remaining
  const bribeCost = user.in_hospital ? Math.max(500, Math.ceil(timeLeft / 60) * 1000) : 0;
  await renderPage(res, 'infirmary', user, { icuList, timeLeft, bribeCost, now });
});

router.post('/infirmary/heal', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const cost = Math.ceil((user.max_hp - user.hp) * 2);
  if (cost <= 0) return res.json({ error: 'Already full HP.' });
  if (user.cash < cost) return res.json({ error: `Need $${cost} to heal.` });
  user.cash -= cost; user.hp = user.max_hp;
  await saveUser(user);
  res.json({ msg: `Healed to full for $${cost}.`, user: statBlock(user) });
});

router.post('/infirmary/bribe', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  if (!user.in_hospital) return res.json({ error: 'You are not in hospital.' });
  const now = Math.floor(Date.now() / 1000);
  const timeLeft = Math.max(0, (user.hospital_until || 0) - now);
  const bribeCost = Math.max(500, Math.ceil(timeLeft / 60) * 1000);
  if (user.cash < bribeCost) return res.json({ error: `Need $${bribeCost.toLocaleString()} to bribe your way out.` });
  user.cash -= bribeCost;
  user.in_hospital = 0;
  user.hospital_until = 0;
  user.hp = Math.max(user.hp, Math.ceil(user.max_hp * 0.3)); // restore to at least 30%
  await saveUser(user);
  res.json({ msg: `Bribed your way out for $${bribeCost.toLocaleString()}! You stumble back to your cell.`, user: statBlock(user) });
});


// ── MARKETPLACE ──
// Market hall landing page
router.get('/market', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  await renderPage(res, 'market_hall', user, {});
});

router.get('/prison/marketplace', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const prisonId = user.prison_id || 1;
  const prison = PRISONS.find(p => p.id === prisonId) || PRISONS[0];
  const maxTier = Math.max(...prison.item_tiers);
  const filterByTier = (obj, tiers) => Object.entries(obj).filter(([k,v]) => tiers.includes(v.tier||1));
  const weaponItems = filterByTier(WEAPONS, prison.weapon_tiers);
  const armorItems  = filterByTier(ARMOR,   prison.armor_tiers);
  const gearItems   = filterByTier(GEAR,    prison.gear_tiers);
  const basicItems  = Object.entries(ITEMS);
  const drugItems   = Object.entries(DRUGS).filter(([k,v]) => (v.tier||1) <= maxTier);
  const activeTab   = req.query.tab || 'weapons';
  await renderPage(res, 'marketplace', user, { weaponItems, armorItems, gearItems, basicItems, drugItems, prison, maxTier, activeTab });
});

router.post('/marketplace/buy', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const { item_key, item_type } = req.body;
  const allCatalog = { ...ITEMS, ...WEAPONS, ...ARMOR, ...GEAR, ...DRUGS };
  const item = allCatalog[item_key];
  if (!item) return res.json({ error: 'Item not found.' });
  if (user.cash < item.price) return res.json({ error: `Need $${item.price.toLocaleString()} to buy this.` });
  user.cash -= item.price;

  // ALL items go straight to inventory — nothing is consumed on purchase
  const type = item_type || (WEAPONS[item_key]?'weapon':ARMOR[item_key]?'armor':GEAR[item_key]?'gear':DRUGS[item_key]?'drug':'item');
  const existing = await get("SELECT id,quantity FROM inventory WHERE user_id=? AND item_key=? AND item_type=?", [user.id, item_key, type]);
  if (existing) {
    await run("UPDATE inventory SET quantity=quantity+1 WHERE id=?", [existing.id]);
  } else {
    await run('INSERT INTO inventory (user_id,item_key,item_type,quantity) VALUES (?,?,?,1)', [user.id, item_key, type]);
  }
  await saveUser(user);
  res.json({ msg: `Bought ${item.name}! Check your Inventory to use it.`, user: statBlock(user) });
});

// ── BANK ──
router.get('/bank', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  await renderPage(res, 'bank', user);
});
router.post('/bank/deposit', requireAuth, progressionAction(async (req, tx) => {
  const user = await getUser(req.session.userId, tx);
  const amount = typeof req.body.amount === 'number' || typeof req.body.amount === 'string' ? Number(req.body.amount) : NaN;
  if (!Number.isSafeInteger(amount) || amount <= 0 || amount > user.cash) return ({ error: 'Invalid amount.' });
  user.cash -= amount; user.bank = (user.bank||0) + amount;
  await saveUser(user, tx.run); return ({ msg: `Deposited $${amount}.`, user: statBlock(user) });
}));
router.post('/bank/withdraw', requireAuth, progressionAction(async (req, tx) => {
  const user = await getUser(req.session.userId, tx);
  const amount = typeof req.body.amount === 'number' || typeof req.body.amount === 'string' ? Number(req.body.amount) : NaN;
  if (!Number.isSafeInteger(amount) || amount <= 0 || amount > (user.bank||0)) return ({ error: 'Invalid amount.' });
  user.cash += amount; user.bank -= amount;
  await saveUser(user, tx.run); return ({ msg: `Withdrew $${amount}.`, user: statBlock(user) });
}));

// ── SHOUTBOX ──
router.get('/shoutbox', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const messages = await all(`SELECT s.*,u.level FROM shoutbox s JOIN users u ON u.id=s.user_id WHERE s.gang_only=0 ORDER BY s.created_at DESC LIMIT 50`);
  await renderPage(res, 'shoutbox', user, { messages: messages.reverse() });
});

// ── INMATES ──
// ── TRANSACTION LOGS ──
router.get('/logs', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const type   = req.query.type || '';
  const page   = Math.max(1, parseInt(req.query.page)||1);
  const limit  = 50;
  const offset = (page - 1) * limit;
  let whereSQL = '';
  const params = [];
  if (type) { whereSQL = 'WHERE type=?'; params.push(type); }
  const logs  = await all(`SELECT * FROM transaction_logs ${whereSQL} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
    [...params, limit, offset]);
  const total = (await get(`SELECT COUNT(*) as c FROM transaction_logs ${whereSQL}`, params))?.c || 0;
  await renderPage(res, 'logs', user, { logs, total, page, limit, type });
});

router.get('/inmates', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const inmates = await all('SELECT id,username,level,rep,wins,losses,gang_id,last_active,in_hospital FROM users ORDER BY rep DESC LIMIT 50');
  await renderPage(res, 'inmates', user, { inmates });
});

// ── PROFILE ──
router.get('/profile/:username', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const profile = await get('SELECT * FROM users WHERE username=?', [req.params.username]);
  if (!profile) return res.redirect('/inmates');
  const gang = profile.gang_id ? await get('SELECT * FROM gangs WHERE id=?', [profile.gang_id]) : null;
  const recentFights = await all(`SELECT a.*,u.username as opp_name FROM attacks a JOIN users u ON u.id=CASE WHEN a.attacker_id=? THEN a.defender_id ELSE a.attacker_id END WHERE a.attacker_id=? OR a.defender_id=? ORDER BY a.created_at DESC LIMIT 8`, [profile.id,profile.id,profile.id]);
  await renderPage(res, 'profile', user, { profile, profileGang: gang, recentFights, profileTitle: getTitle(profile.rep), PRISONS });
});

router.post('/profile/update-blurb', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const blurb = (req.body.blurb||'').slice(0,100);
  await run('UPDATE users SET blurb=? WHERE id=?', [blurb, user.id]);
  res.json({ msg: 'Blurb saved.' });
});

// ── MAIL ──
router.get('/mail', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const inbox = await all(`SELECT m.*,u.username as from_name FROM mail m JOIN users u ON u.id=m.from_id WHERE m.to_id=? ORDER BY m.created_at DESC LIMIT 20`, [user.id]);
  await run('UPDATE mail SET read=1 WHERE to_id=?', [user.id]);
  await renderPage(res, 'mail', user, { inbox });
});
router.post('/mail/send', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const { to, subject, body } = req.body;
  if (!to||!body) return res.json({ error: 'Fill in all fields.' });
  const target = await get('SELECT id FROM users WHERE username=?', [to]);
  if (!target) return res.json({ error: 'User not found.' });
  await run('INSERT INTO mail (from_id,to_id,subject,body) VALUES (?,?,?,?)', [user.id, target.id, subject||'No Subject', body]);
  await addEvent(target.id, 'mail', `New mail from ${user.username}: "${subject||'No Subject'}"`);
  res.json({ msg: `Mail sent to ${to}.` });
});

// ── EVENTS ──
router.get('/events', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const events = await all('SELECT * FROM events WHERE user_id=? ORDER BY created_at DESC LIMIT 30', [user.id]);
  await run('UPDATE events SET read=1 WHERE user_id=?', [user.id]);
  await renderPage(res, 'events', user, { events });
});

// ── MOST WANTED ──
router.get('/most-wanted', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const wanted = await all('SELECT id,username,level,rep,wins,losses FROM users ORDER BY rep DESC LIMIT 20');
  await renderPage(res, 'most_wanted', user, { wanted });
});

// ── HITLIST ──
router.get('/hitlist', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const hits = await all(`SELECT h.*,u.username as target_name,u2.username as poster_name FROM hitlist h JOIN users u ON u.id=h.target_id JOIN users u2 ON u2.id=h.poster_id WHERE h.active=1 ORDER BY h.reward DESC`);
  await renderPage(res, 'hitlist', user, { hits });
});
router.post('/hitlist/add', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const { target_name, reward, reason } = req.body;
  const r = parseInt(reward)||0;
  if (r < 100) return res.json({ error: 'Min $100.' });
  if (user.cash < r) return res.json({ error: 'Not enough cash.' });
  const target = await get('SELECT id FROM users WHERE username=?', [target_name]);
  if (!target) return res.json({ error: 'User not found.' });
  user.cash -= r;
  await run('UPDATE users SET cash=? WHERE id=?', [user.cash, user.id]);
  await run('INSERT INTO hitlist (target_id,poster_id,reward,reason) VALUES (?,?,?,?)', [target.id, user.id, r, reason||'']);
  await addEvent(target.id, 'hitlist', `You have a $${r} bounty on your head!`);
  res.json({ msg: `Placed $${r} bounty on ${target_name}.` });
});

// ── ISOLATION ──
router.get('/isolation', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const jailed = await all('SELECT id,username,level,jail_until,jail_reason FROM users WHERE in_jail=1 ORDER BY jail_until ASC');
  const now = Math.floor(Date.now()/1000);
  const timeLeft = Math.max(0, (user.jail_until||0) - now);
  const bribeCost = Math.max(200, Math.ceil(timeLeft/60) * 500);
  await renderPage(res, 'isolation', user, { jailed, now, timeLeft, bribeCost });
});

router.post('/isolation/bribe', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  if (!user.in_jail) return res.json({ error: 'You are not in isolation.' });
  const now = Math.floor(Date.now()/1000);
  const timeLeft = Math.max(0, (user.jail_until||0) - now);
  const bribeCost = Math.max(200, Math.ceil(timeLeft/60) * 500);
  if (user.cash < bribeCost) return res.json({ error: `Need $${bribeCost.toLocaleString()} to bribe out.` });
  user.cash -= bribeCost;
  user.in_jail = 0;
  user.jail_until = 0;
  user.jail_reason = null;
  await saveUser(user);
  res.json({ msg: `Bribed your way out for $${bribeCost.toLocaleString()}!`, user: statBlock(user) });
});


// ── API STATS ──
router.get('/api/stats', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  res.json(statBlock(user));
});

module.exports = router;

// ── EQUIPMENT ──

router.get('/equipment', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const equipped = await get('SELECT * FROM equipment WHERE user_id=?', [user.id]) || { weapon:null, armor:null, gear:null };
  const invWeapons  = await all("SELECT * FROM inventory WHERE user_id=? AND item_type='weapon'",  [user.id]);
  const invArmor    = await all("SELECT * FROM inventory WHERE user_id=? AND item_type='armor'",   [user.id]);
  const invGear     = await all("SELECT * FROM inventory WHERE user_id=? AND item_type='gear'",    [user.id]);
  await renderPage(res, 'equipment', user, { equipped, invWeapons, invArmor, invGear, WEAPONS, ARMOR, GEAR });
});

router.post('/equipment/equip', requireAuth, progressionAction(async (req, tx) => {
  const { action, slot, key } = req.body;
  const catalog = { weapon: WEAPONS, armor: ARMOR, gear: GEAR };
  if (!['weapon','armor','gear'].includes(slot) || !['equip','unequip'].includes(action)) return { error: 'Invalid equipment action.' };
  if (action === 'equip') {
    if (!Object.hasOwn(catalog[slot], key)) return { error: 'Unknown equipment.' };
    const owned = await tx.get('SELECT id FROM inventory WHERE user_id=? AND item_key=? AND item_type=? AND quantity>0', [req.session.userId, key, slot]);
    if (!owned) return { error: "You don't own that item." };
  }
  await tx.run('INSERT OR IGNORE INTO equipment (user_id) VALUES (?)', [req.session.userId]);
  await tx.run(`UPDATE equipment SET ${slot}=? WHERE user_id=?`, [action === 'unequip' ? null : key, req.session.userId]);
  return { msg: action === 'unequip' ? 'Unequipped.' : 'Equipped! Bonuses apply to your stats and combat.', user: statBlock(await getUser(req.session.userId, tx)) };
}));

// ── INVENTORY ──
router.get('/inventory', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const invItems = await all("SELECT * FROM inventory WHERE user_id=? AND (item_type='item' OR item_type='drug')", [user.id]);
  const collectibleCount=(await get("SELECT COALESCE(SUM(quantity),0) AS n FROM inventory WHERE user_id=? AND item_type='collectible'",[user.id])).n;
  const cooldowns = await all('SELECT * FROM recovery_cooldowns WHERE user_id=?', [user.id]);
  await renderPage(res, 'inventory', user, { invItems, ITEMS, DRUGS, cooldowns, recoveryGroup, collectibleCount, now: Math.floor(Date.now() / 1000) });
});

router.post('/inventory/use', requireAuth, progressionAction(async (req, tx) => {
  const user = await getUser(req.session.userId, tx);
  const { item_key } = req.body;
  const requestedType = req.body.item_type;
  if (typeof item_key !== 'string' || (requestedType !== undefined && !['item', 'drug'].includes(requestedType))) return { error: 'Invalid item.' };
  const owned = requestedType
    ? await tx.get('SELECT * FROM inventory WHERE user_id=? AND item_key=? AND item_type=? AND quantity>0', [user.id, item_key, requestedType])
    : await tx.get("SELECT * FROM inventory WHERE user_id=? AND item_key=? AND item_type IN ('item','drug') AND quantity>0 ORDER BY item_type LIMIT 1", [user.id, item_key]);
  if (!owned) return { error: "You don't own that." };
  const catalog = owned.item_type === 'drug' ? DRUGS : ITEMS;
  const item = Object.hasOwn(catalog, item_key) ? catalog[item_key] : null;
  if (!item || (!item.consumable && !item.permanent)) return { error: 'This item cannot be used directly.' };
  if (user.in_jail) return { error: 'Items cannot be used in isolation.' };
  const group = recoveryGroup(item, owned.item_type);
  const now = Math.floor(Date.now() / 1000);
  const cooldown = await tx.get('SELECT ready_at FROM recovery_cooldowns WHERE user_id=? AND category=?', [user.id, group.key]);
  if (cooldown?.ready_at > now) return { error: `${group.label} cooldown: wait ${Math.ceil((cooldown.ready_at - now) / 60)} minutes.`, readyAt: cooldown.ready_at };
  const e = item.effect;
  const before = JSON.stringify([user.hp, user.energy, user.nerve, user.stamina, user.strength, user.defense, user.speed]);
  for (const [stat, max] of [['hp', 'max_hp'], ['energy', 'max_energy'], ['nerve', 'max_nerve']]) {
    if (e[stat]) user[stat] = Math.min(user[max], user[stat] + e[stat]);
  }
  if (e.stamina) user.stamina = Math.min(100, user.stamina + e.stamina);
  if (item.permanent) for (const stat of ['strength', 'defense', 'speed']) if (e[stat]) user[stat] += e[stat];
  // A temporary speed bonus is not implemented; cocaine explicitly restores energy only.
  if (before === JSON.stringify([user.hp, user.energy, user.nerve, user.stamina, user.strength, user.defense, user.speed])) return { error: 'Your resources are already full. Item kept.' };
  await tx.run('UPDATE inventory SET quantity=quantity-1 WHERE id=?', [owned.id]);
  await tx.run('DELETE FROM inventory WHERE id=? AND quantity=0', [owned.id]);
  await tx.run(`INSERT INTO recovery_cooldowns (user_id,category,ready_at) VALUES (?,?,?)
    ON CONFLICT(user_id,category) DO UPDATE SET ready_at=excluded.ready_at`, [user.id, group.key, now + group.duration]);
  await saveUser(user, tx.run);
  return { msg: `Used ${item.name}! ${group.label} recovery: ${group.duration / 60} minutes.`, user: statBlock(user), category: group.key, readyAt: now + group.duration };
}));

router.post('/inventory/drop', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const { item_key, item_type } = req.body;
  await run("DELETE FROM inventory WHERE user_id=? AND item_key=? AND item_type=?", [user.id, item_key, item_type]);
  res.json({ ok: true });
});

router.post(['/inventory/list','/openmarket/list'], requireAuth, progressionAction(async (req,tx) => {
  const user=await getUser(req.session.userId,tx);
  const {item_key,item_type}=req.body;
  const price=wholeNumber(req.body.price),qty=wholeNumber(req.body.quantity ?? 1);
  if(!['item','drug','weapon','armor','gear','collectible','amenity'].includes(item_type) || typeof item_key!=='string' || !Number.isSafeInteger(price) || price<1 || price>1000000000 || !Number.isSafeInteger(qty) || qty<1 || qty>1000000) return {error:'Enter a valid item, whole quantity and total asking price.'};
  if(item_type==='collectible') {
    if(!Object.hasOwn(TRAVEL_ITEMS,item_key) || !await takeInventory(tx,user.id,item_key,qty)) return {error:'You do not own enough of that collectible.'};
  } else if(item_type==='amenity') {
    const rows=await tx.all('SELECT id FROM cell_amenities WHERE user_id=? AND item_key=? AND placed_tile IS NULL ORDER BY id LIMIT ?',[user.id,item_key,qty]);
    if(rows.length<qty) return {error:'Not enough unplaced amenities.'};
    for(const row of rows) await tx.run('DELETE FROM cell_amenities WHERE id=?',[row.id]);
  } else {
    const row=await tx.get('SELECT * FROM inventory WHERE user_id=? AND item_key=? AND item_type=?',[user.id,item_key,item_type]);
    if(!row || row.quantity<qty) return {error:'You do not own enough of that item.'};
    if(row.quantity===qty) await tx.run('DELETE FROM inventory WHERE id=?',[row.id]);
    else await tx.run('UPDATE inventory SET quantity=quantity-? WHERE id=?',[qty,row.id]);
  }
  await tx.run('INSERT INTO open_market (seller_id,prison_id,item_type,item_key,quantity,price) VALUES (?,?,?,?,?,?)',[user.id,user.prison_id,item_type,item_key,qty,price]);
  return {msg:`Listed ${qty} × ${TRAVEL_ITEMS[item_key]?.name || item_key} for $${price.toLocaleString()} total. The market takes a 10% sale fee.`};
}));

// ── OPEN MARKET ──
router.get('/openmarket', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const prisonId = user.prison_id || 1;
  const prison = PRISONS.find(p => p.id === prisonId) || PRISONS[0];
  const selCat = req.query.cat || null;
  const rows = await all(`SELECT om.*, u.username as seller_name FROM open_market om JOIN users u ON u.id=om.seller_id WHERE om.active=1 AND om.prison_id=? ORDER BY om.listed_at DESC`, [prisonId]);

  const allItemData = { ...ITEMS, ...DRUGS, ...WEAPONS, ...ARMOR, ...GEAR, ...TRAVEL_ITEMS };
  const listings = rows.map(r => {
    const item = allItemData[r.item_key] || CELL_AMENITIES[r.item_key];
    return { ...r, img: item?.img||null, display_name: item?.name||r.item_key, desc: item?.desc||'' };
  });

  // Build user's sellable inventory for selected category
  const invRows = await all("SELECT * FROM inventory WHERE user_id=?", [user.id]);
  const inventory = invRows.map(r => {
    const item = allItemData[r.item_key];
    return { item_key: r.item_key, item_type: r.item_type, display_name: item?.name||r.item_key, quantity: r.quantity };
  });
  const ownedAmens = await all("SELECT item_key, COUNT(*) as qty FROM cell_amenities WHERE user_id=? AND placed_tile IS NULL GROUP BY item_key", [user.id]);
  ownedAmens.forEach(a => {
    const item = CELL_AMENITIES[a.item_key];
    if (item) inventory.push({ item_key: a.item_key, item_type:'amenity', display_name: item.name, quantity: a.qty });
  });

  await renderPage(res, 'openmarket', user, { listings, prison, inventory, selCat });
});

router.post('/openmarket/buy', requireAuth, progressionAction(async (req,tx) => {
  const user=await getUser(req.session.userId,tx);
  const id=wholeNumber(req.body.listing_id);
  if(!Number.isSafeInteger(id)||id<1) return {error:'Invalid listing.'};
  const listing=await tx.get('SELECT * FROM open_market WHERE id=? AND active=1',[id]);
  if(!listing) return {error:'Listing not found or already sold.'};
  if(listing.seller_id===user.id) return {error:'You cannot buy your own listing.'};
  if(listing.prison_id!==user.prison_id) return {error:'Wrong prison.'};
  if(user.cash<listing.price) return {error:`Need $${listing.price}.`};
  const sellerGets=listing.price-Math.floor(listing.price*0.1);
  await tx.run('UPDATE users SET cash=cash-? WHERE id=?',[listing.price,user.id]);
  await tx.run('UPDATE users SET cash=cash+? WHERE id=?',[sellerGets,listing.seller_id]);
  await tx.run('UPDATE open_market SET active=0 WHERE id=?',[id]);
  if(listing.item_type==='collectible') await receiveCollectible(tx,user.id,listing.item_key,listing.quantity);
  else if(listing.item_type==='amenity') {
    for(let i=0;i<listing.quantity;i++) await tx.run('INSERT INTO cell_amenities (user_id,item_key) VALUES (?,?)',[user.id,listing.item_key]);
  } else {
    const owned=await tx.get('SELECT id FROM inventory WHERE user_id=? AND item_key=? AND item_type=?',[user.id,listing.item_key,listing.item_type]);
    if(owned) await tx.run('UPDATE inventory SET quantity=quantity+? WHERE id=?',[listing.quantity,owned.id]);
    else await tx.run('INSERT INTO inventory (user_id,item_key,item_type,quantity) VALUES (?,?,?,?)',[user.id,listing.item_key,listing.item_type,listing.quantity]);
  }
  await tx.run("INSERT INTO events (user_id,type,message) VALUES (?,'market',?)",[listing.seller_id,`Your listing sold for $${sellerGets} (after 10% fee).`]);
  await tx.run(`INSERT INTO transaction_logs (type,from_id,from_name,to_id,item_key,item_type,quantity,cash_amount,note) VALUES ('market_sale',?,?,?,?,?,?,?,?)`,[user.id,user.username,listing.seller_id,listing.item_key,listing.item_type,listing.quantity,listing.price,'Open Market sale']);
  return {msg:`Bought ${listing.quantity} × ${TRAVEL_ITEMS[listing.item_key]?.name || listing.item_key} for $${listing.price}.`,user:statBlock(await getUser(user.id,tx))};
}));
router.post('/openmarket/cancel', requireAuth, progressionAction(async (req,tx) => {
  const id=wholeNumber(req.body.listing_id);
  if(!Number.isSafeInteger(id)||id<1) return {error:'Invalid listing.'};
  const listing=await tx.get('SELECT * FROM open_market WHERE id=? AND seller_id=? AND active=1',[id,req.session.userId]);
  if(!listing) return {error:'Listing not found.'};
  await tx.run('UPDATE open_market SET active=0 WHERE id=?',[id]);
  if(listing.item_type==='collectible') await addInventory(tx,req.session.userId,listing.item_key,listing.quantity);
  else if(listing.item_type==='amenity') {
    for(let i=0;i<listing.quantity;i++) await tx.run('INSERT INTO cell_amenities (user_id,item_key) VALUES (?,?)',[req.session.userId,listing.item_key]);
  } else {
    const owned=await tx.get('SELECT id FROM inventory WHERE user_id=? AND item_key=? AND item_type=?',[req.session.userId,listing.item_key,listing.item_type]);
    if(owned) await tx.run('UPDATE inventory SET quantity=quantity+? WHERE id=?',[listing.quantity,owned.id]);
    else await tx.run('INSERT INTO inventory (user_id,item_key,item_type,quantity) VALUES (?,?,?,?)',[req.session.userId,listing.item_key,listing.item_type,listing.quantity]);
  }
  return {msg:'Listing cancelled. All items returned.'};
}));

// ── JOBS ──
// ═══════════════════════════════════════════════════════════
router.get('/jobs', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const prisonJobs = JOBS[user.prison_id] || [];
  const now = Math.floor(Date.now()/1000);
  const nextPay = user.last_daily_pay ? Math.max(0, (user.last_daily_pay + 86400) - now) : 0;
  await renderPage(res, 'jobs', user, { prisonJobs, nextPay });
});

router.post('/jobs/take', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const { job_key } = req.body;
  const prisonJobs = JOBS[user.prison_id] || [];
  const job = prisonJobs.find(j => j.key === job_key);
  if (!job) return res.json({ error: 'Invalid job.' });
  if (user.defense < job.req_def) return res.json({ error: `Need ${job.req_def} DEF for this job.` });
  await run('UPDATE users SET job_key=?, job_prison_id=?, last_daily_pay=? WHERE id=?',
    [job.key, user.prison_id, Math.floor(Date.now()/1000), user.id]);
  res.json({ msg: `You're now working as: ${job.name}. Pay of $${job.base_pay}+ deposited automatically every 24 hours.` });
});

router.post('/jobs/quit', requireAuth, async (req, res) => {
  await run('UPDATE users SET job_key=NULL, job_prison_id=NULL WHERE id=?', [req.session.userId]);
  res.json({ msg: 'You quit your job.' });
});

// ═══════════════════════════════════════════════════════════
// ── MUGGING ──
// ═══════════════════════════════════════════════════════════
// ── SPYING ──
// ═══════════════════════════════════════════════════════════
router.get('/spy/:username', requireAuth, async (req, res) => {
  const user   = await getUser(req.session.userId);
  const target = await get('SELECT * FROM users WHERE username=? COLLATE NOCASE', [req.params.username]);
  if (!target) return res.redirect('/inmates');
  const spyCost = 450 * target.level;
  const recent  = await all('SELECT * FROM spy_logs WHERE spy_id=? AND target_id=? ORDER BY created_at DESC LIMIT 1', [user.id, target.id]).catch(()=>[]);
  await renderPage(res, 'spy', user, { target, spyCost, lastResult: recent[0] || null });
});

router.post('/spy', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const { target_id } = req.body;
  const tid    = parseInt(target_id);
  const target = await getUser(tid);
  if (!target || target.id === user.id) return res.json({ error: 'Invalid target.' });
  if (target.prison_id !== user.prison_id) return res.json({ error: 'Can only spy on inmates in your prison.' });
  const spyCost = 450 * target.level;
  if (user.cash < spyCost) return res.json({ error: `Need $${spyCost.toLocaleString()} to spy on this inmate.` });

  user.cash -= spyCost;

  // Fetch everything — each section has independent 65% success chance
  const hit = () => Math.random() > 0.35;
  const allItems   = await all("SELECT item_key,item_type,quantity FROM inventory WHERE user_id=?", [tid]);
  const cellAmens  = await all('SELECT item_key FROM cell_amenities WHERE user_id=? AND placed_tile IS NOT NULL', [tid]);
  const unplaced   = await all('SELECT item_key FROM cell_amenities WHERE user_id=? AND placed_tile IS NULL', [tid]);

  const result = {
    bank:       hit() ? target.bank     : null,
    favors:     hit() ? (target.favors||0) : null,
    xp_pct:    hit() ? Math.floor((target.xp / Math.max(1,target.xp_needed))*100) : null,
    speed:      hit() ? target.speed    : null,
    strength:   hit() ? target.strength : null,
    defense:    hit() ? target.defense  : null,
    stamina:    hit() ? target.stamina  : null,
    // Items split by type
    items:      hit() ? allItems.filter(i=>i.item_type==='item')   : null,
    weapons:    hit() ? allItems.filter(i=>i.item_type==='weapon') : null,
    armor:      hit() ? allItems.filter(i=>i.item_type==='armor')  : null,
    drugs:      hit() ? allItems.filter(i=>i.item_type==='drug')   : null,
    // Cell contents (placed + unplaced, no protected flag shown)
    cell_placed:   hit() ? cellAmens.map(c=>c.item_key) : null,
    cell_unplaced: hit() ? unplaced.map(c=>c.item_key)  : null,
  };

  // Log the spy action
  await run('INSERT INTO spy_logs (spy_id,target_id,result,cost) VALUES (?,?,?,?)',
    [user.id, tid, JSON.stringify(result), spyCost]).catch(()=>{});
  await run(`INSERT INTO transaction_logs (type,from_id,from_name,to_id,to_name,cash_amount,note) VALUES (?,?,?,?,?,?,?)`,
    ['spy', user.id, user.username, tid, target.username, spyCost, `Spy report on ${target.username}`]).catch(()=>{});
  await saveUser(user);
  res.json({ result, target: { username: target.username, level: target.level }, msg: `Spy report on ${target.username} complete. Cost: $${spyCost.toLocaleString()}.`, user: statBlock(user) });
});

// ═══════════════════════════════════════════════════════════
// ── CELL RAIDING ──
// ═══════════════════════════════════════════════════════════
router.get('/raid/:username', requireAuth, async (req, res) => {
  const user   = await getUser(req.session.userId);
  const target = await get('SELECT id,username,prison_id FROM users WHERE username=? COLLATE NOCASE', [req.params.username]);
  if (!target) return res.redirect('/inmates');
  if (target.prison_id !== user.prison_id) return res.redirect('/inmates');
  const now = Math.floor(Date.now()/1000);
  const cd  = await get('SELECT last_raid FROM raid_cooldowns WHERE raider_id=? AND target_id=?', [user.id, target.id]).catch(()=>null);
  const cdLeft = cd ? Math.max(0, 1800 - (now - cd.last_raid)) : 0;
  // Previous attempts this session (cleared when target changes combo)
  const prevAttempts = await all('SELECT combo_tried,correct_positions FROM raid_attempts WHERE raider_id=? AND target_id=? ORDER BY created_at DESC LIMIT 8', [user.id, target.id]).catch(()=>[]);
  // Get combo length (may have been extended by target)
  const comboRow = await get('SELECT combo FROM cell_combos WHERE user_id=?', [target.id]).catch(()=>null);
  const combo = comboRow?.combo || '12345';
  await renderPage(res, 'raid', user, { target, cdLeft, prevAttempts, comboLength: combo.length });
});

router.post('/raid/attempt', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const { target_id, combo_try } = req.body;
  const tid = parseInt(target_id);
  if (user.nerve < 10) return res.json({ error: 'Need 10 Nerve to raid.' });
  if (user.in_hospital || user.in_jail) return res.json({ error: "You can't raid from here." });
  const now = Math.floor(Date.now()/1000);
  const cd  = await get('SELECT last_raid FROM raid_cooldowns WHERE raider_id=? AND target_id=?', [user.id, tid]).catch(()=>null);
  if (cd && now - cd.last_raid < 1800) {
    const wait = Math.ceil((1800 - (now - cd.last_raid)) / 60);
    return res.json({ error: `Wait ${wait} more minute${wait!==1?'s':''} before raiding again.` });
  }

  const target = await getUser(tid);
  if (!target || target.prison_id !== user.prison_id) return res.json({ error: 'Invalid target.' });

  const comboRow = await get('SELECT combo FROM cell_combos WHERE user_id=?', [tid]).catch(()=>null);
  const realCombo = comboRow?.combo || '12345';
  const tryStr = String(combo_try).slice(0, realCombo.length);

  // Mark correct digits (green = right digit right position)
  const correctPos = [];
  for (let i = 0; i < realCombo.length; i++) {
    correctPos.push(tryStr[i] === realCombo[i] ? 'correct' : (realCombo.includes(tryStr[i]) ? 'present' : 'wrong'));
  }

  user.nerve -= 10;
  await run('INSERT OR REPLACE INTO raid_cooldowns VALUES (?,?,?)', [user.id, tid, now]);
  await run('INSERT INTO raid_attempts (raider_id,target_id,combo_tried,correct_positions) VALUES (?,?,?,?)',
    [user.id, tid, tryStr, JSON.stringify(correctPos)]).catch(()=>{});

  if (tryStr === realCombo) {
    // SUCCESS — loot the cell
    user.xp += 30 + target.level * 5;
    let loot = [];
    // Steal cash from bank (10-25%)
    const bankSteal = Math.floor(target.bank * (0.1 + Math.random() * 0.15));
    if (bankSteal > 0) {
      await run('UPDATE users SET bank=MAX(0,bank-?) WHERE id=?', [bankSteal, tid]);
      user.cash += bankSteal;
      loot.push(`$${bankSteal} from bank`);
    }
    // Steal unprotected cell items (5-7% chance per item)
    const placed = await all('SELECT * FROM cell_amenities WHERE user_id=? AND placed_tile IS NOT NULL AND protected=0', [tid]);
    for (const item of placed) {
      if (Math.random() < 0.06) {
        await run('DELETE FROM cell_amenities WHERE id=?', [item.id]);
        const ex = await get('SELECT id,quantity FROM cell_amenities WHERE user_id=? AND item_key=?', [user.id, item.item_key]);
        if (ex) await run('UPDATE cell_amenities SET quantity=quantity+1 WHERE id=?', [ex.id]);
        else await run('INSERT INTO cell_amenities (user_id,item_key,quantity,protected) VALUES (?,?,1,0)', [user.id, item.item_key]);
        loot.push(item.item_key.replace(/_/g,' '));
      }
    }
    // Warden resets combo after successful raid
    const newCombo = Array.from({length: realCombo.length}, () => rnd(10)).join('');
    await run('INSERT OR REPLACE INTO cell_combos VALUES (?,?)', [tid, newCombo]);
    await run('DELETE FROM raid_attempts WHERE raider_id=? AND target_id=?', [user.id, tid]);

    await addEvent(tid, 'raided', `${user.username} cracked your cell combination and raided your cell! Lost: ${loot.join(', ') || 'nothing valuable'}.`);
    const lvlUp = await levelUpCheck(user, run);
    await saveUser(user);
    return res.json({ success: true, cracked: true, loot, msg: `Cell cracked! Looted: ${loot.join(', ') || 'nothing valuable'}.`, correctPos, user: statBlock(user), levelUp: lvlUp });
  }

  // WRONG COMBO — maybe caught
  const caughtChance = 35;
  const escaped = Math.random() * 100 > caughtChance;
  await saveUser(user);
  if (!escaped) {
    const isoTime = 180 + rnd(180);
    await run('UPDATE users SET in_jail=1, jail_until=?, jail_reason=? WHERE id=?',
      [now + isoTime, `Caught raiding ${target.username}'s cell`, user.id]);
    return res.json({ success: false, cracked: false, caught: true, correctPos, msg: `Wrong combo — you were caught! Isolation for ${Math.ceil(isoTime/60)} minutes.`, user: statBlock(user) });
  }
  return res.json({ success: false, cracked: false, caught: false, correctPos, msg: 'Wrong combo — but you slipped away.', user: statBlock(user) });
});

router.post('/cell/change-combo', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const { new_combo } = req.body;
  if (!new_combo || !/^[a-zA-Z0-9]{4,8}$/.test(new_combo))
    return res.json({ error: 'Combo must be 4-8 alphanumeric characters.' });
  const cost = 500;
  if (user.cash < cost) return res.json({ error: `Costs $${cost} to change your combo.` });
  user.cash -= cost;
  await saveUser(user);
  await run('INSERT OR REPLACE INTO cell_combos VALUES (?,?)', [user.id, new_combo]);
  await run('DELETE FROM raid_attempts WHERE target_id=?', [user.id]);
  res.json({ msg: `Combo changed to: ${new_combo}. Previous raid attempts erased.`, user: statBlock(user) });
});

// ═══════════════════════════════════════════════════════════
// ── SEND MONEY ──
// ═══════════════════════════════════════════════════════════
router.get('/send-money', requireAuth, async (req, res) => {
  const user    = await getUser(req.session.userId);
  const inmates = await all('SELECT id,username,level,prison_id FROM users WHERE id!=? ORDER BY username ASC', [user.id]);
  await renderPage(res, 'send_money', user, { inmates, PRISONS });
});

router.post('/send-money', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const { target_id, amount } = req.body;
  const amt = parseInt(amount);
  if (!amt || amt < 1) return res.json({ error: 'Invalid amount.' });
  if (user.cash < amt)  return res.json({ error: 'Not enough cash on hand.' });
  const target = await get('SELECT id,username,prison_id FROM users WHERE id=?', [parseInt(target_id)]);
  if (!target || target.id === user.id) return res.json({ error: 'Invalid recipient.' });
  const samePrison = target.prison_id === user.prison_id;
  const fee = samePrison ? Math.ceil(amt * 0.10) : Math.ceil(amt * 0.20);
  const total = amt + fee;
  if (user.cash < total) return res.json({ error: `Need $${total.toLocaleString()} total ($${amt} + $${fee} fee).` });
  user.cash -= total;
  await run('UPDATE users SET cash=cash+? WHERE id=?', [amt, target.id]);
  await addEvent(target.id, 'money', `${user.username} sent you $${amt.toLocaleString()}.`);
  await saveUser(user);
  res.json({ msg: `Sent $${amt.toLocaleString()} to ${target.username}. Fee: $${fee} (${samePrison?'10%':'20%'}).`, user: statBlock(user) });
});

// ═══════════════════════════════════════════════════════════
// ── FAVORS ──
// ═══════════════════════════════════════════════════════════
router.post('/favors/vote', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const now  = Math.floor(Date.now()/1000);
  const lastVote = user.last_daily_pay || 0; // reuse field for simplicity — we'll use a new one
  // Use a dedicated tracking: check events for today's vote
  const todayVote = await get("SELECT id FROM events WHERE user_id=? AND type='vote' AND created_at > ?",
    [user.id, now - 86400]).catch(()=>null);
  if (todayVote) return res.json({ error: 'Already claimed your daily vote favor. Come back tomorrow!' });
  user.favors = (user.favors || 0) + 1;
  await run('UPDATE users SET favors=? WHERE id=?', [user.favors, user.id]);
  await run("INSERT INTO events (user_id,type,message) VALUES (?,'vote','Earned 1 favor from voting.')", [user.id]);
  res.json({ msg: '+1 Favor earned! Thanks for voting.', favors: user.favors });
});

// ── PRISON TRANSPORT ──
router.get('/transport', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const WEAPONS_LIST = Object.entries(WEAPONS).map(([k,v])=>({key:k,...v}));
  await renderPage(res, 'transport', user, { PRISONS, WEAPONS_LIST });
});

router.post('/transport/move', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const { prison_id } = req.body;
  const prison = PRISONS.find(p => p.id === parseInt(prison_id));
  if (!prison) return res.json({ error: 'Invalid prison.' });
  if (user.level < prison.level_req) return res.json({ error: `Requires Level ${prison.level_req}.` });
  if ((user.prison_id||1) === prison.id) return res.json({ error: "You're already at this prison." });
  const TRANSFER_COSTS = { 1:0, 2:2000, 3:5000, 4:12000, 5:35000 };
  const cost = TRANSFER_COSTS[prison.id] || 0;
  if (user.cash < cost) return res.json({ error: `Need $${cost.toLocaleString()} to transfer.` });
  user.cash -= cost;

  // ── ON TRANSFER: lose job, remove market listings, clear cell, bank transfer, reset combo ──
  // 1. Lose job
  await run('UPDATE users SET job_key=NULL, job_prison_id=NULL WHERE id=?', [user.id]);
  // 2. Remove open market listings → return to inventory
  const myListings = await all("SELECT * FROM open_market WHERE seller_id=? AND active=1", [user.id]);
  for (const listing of myListings) {
    await run("UPDATE open_market SET active=0 WHERE id=?", [listing.id]);
    const existing = await get("SELECT id,quantity FROM inventory WHERE user_id=? AND item_key=? AND item_type=?", [user.id, listing.item_key, listing.item_type]);
    if (existing) await run("UPDATE inventory SET quantity=quantity+? WHERE id=?", [listing.quantity, existing.id]);
    else await run("INSERT INTO inventory (user_id,item_key,item_type,quantity) VALUES (?,?,?,?)", [user.id, listing.item_key, listing.item_type, listing.quantity]);
  }
  // 3. Unplace cell amenities (keep in possession, just unplace)
  await run('UPDATE cell_amenities SET placed_tile=NULL WHERE user_id=?', [user.id]);
  // 4. Bank: if no existing account at new prison, cash out (simple: just keep bank balance — player must re-open)
  if (user.bank > 0) {
    user.cash += user.bank;
    user.bank = 0;
    await run('UPDATE users SET bank=0 WHERE id=?', [user.id]);
  }
  // 5. Reset cell combo
  const newCombo = Array.from({length:5}, ()=>rnd(10)).join('');
  await run('INSERT OR REPLACE INTO cell_combos VALUES (?,?)', [user.id, newCombo]);
  await run('DELETE FROM raid_attempts WHERE target_id=?', [user.id]);
  // 6. Resize cell to new prison max
  await run('UPDATE users SET prison_id=?, cell_size=? WHERE id=?', [prison.id, prison.max_cell, user.id]);

  await saveUser(user);

  const notes = [
    `Transferred to ${prison.name}.`,
    cost > 0 ? `Transfer cost: $${cost.toLocaleString()}.` : null,
    myListings.length ? `${myListings.length} market listing${myListings.length!==1?'s':''} returned to inventory.` : null,
    'Cell amenities unloaded — re-arrange your cell.',
    user.bank > 0 ? `Bank balance ($${user.bank.toLocaleString()}) transferred to cash.` : null,
    `New cell combo set. New max cell: ${prison.max_cell}.`,
  ].filter(Boolean);

  await addEvent(user.id, 'transport', notes.join(' '));
  res.json({ msg: notes.join(' '), redirect: '/prison' });
});



// ── SURGEON ──
const { AVATAR_CATEGORIES, AVATAR_PARTS, DEFAULT_AVATAR } = require('../middleware/avatardata');

router.get('/surgeon', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const presets = await all('SELECT * FROM avatar_presets WHERE user_id=? ORDER BY slot', [user.id]);
  const presetsData = presets.map(p => ({ ...p, layers: JSON.parse(p.layers || '{}') }));
  const unlockRows = await all('SELECT item_key FROM surgeon_unlocks WHERE user_id=?', [user.id]);
  const unlocked = unlockRows.map(r => r.item_key);
  let currentAvatar = DEFAULT_AVATAR;
  if (user.avatar) {
    try { currentAvatar = { ...DEFAULT_AVATAR, ...JSON.parse(user.avatar) }; } catch(e) {}
  }
  await renderPage(res, 'surgeon', user, {
    AVATAR_CATEGORIES, AVATAR_PARTS, DEFAULT_AVATAR,
    presets, presetsData, unlocked, currentAvatar
  });
});

router.post('/surgeon/save', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const { layers } = req.body;
  if (!layers || typeof layers !== 'object') return res.json({ error: 'Invalid data.' });
  // Only save keys that exist in categories
  const validKeys = Object.keys(DEFAULT_AVATAR);
  const clean = {};
  validKeys.forEach(k => { if (layers[k]) clean[k] = layers[k]; });
  await run('UPDATE users SET avatar=? WHERE id=?', [JSON.stringify(clean), user.id]);
  res.json({ ok: true, msg: 'Avatar saved!' });
});

router.post('/surgeon/preset/save', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const { slot, layers } = req.body;
  if (!slot || slot < 1 || slot > 5) return res.json({ error: 'Invalid slot.' });
  await run('INSERT OR REPLACE INTO avatar_presets (user_id, slot, layers) VALUES (?,?,?)',
    [user.id, slot, JSON.stringify(layers)]);
  res.json({ ok: true });
});

router.post('/surgeon/buy', requireAuth, async (req, res) => {
  const user = await getUser(req.session.userId);
  const { item_key } = req.body;
  // Find part in any category
  let part = null;
  for (const cat of Object.keys(AVATAR_PARTS)) {
    part = AVATAR_PARTS[cat].find(p => p.key === item_key);
    if (part) break;
  }
  if (!part) return res.json({ error: 'Part not found.' });
  if (part.free) return res.json({ error: 'This part is already free.' });
  const alreadyOwned = await get('SELECT 1 FROM surgeon_unlocks WHERE user_id=? AND item_key=?', [user.id, item_key]);
  if (alreadyOwned) return res.json({ error: 'Already unlocked.' });
  if (user.rep < part.rep_cost) return res.json({ error: `Need ${part.rep_cost} Rep. You have ${user.rep}.` });
  user.rep -= part.rep_cost;
  await run('UPDATE users SET rep=? WHERE id=?', [user.rep, user.id]);
  await run('INSERT INTO surgeon_unlocks (user_id, item_key) VALUES (?,?)', [user.id, item_key]);
  res.json({ ok: true, msg: `Unlocked ${part.name}!`, rep: user.rep });
});
